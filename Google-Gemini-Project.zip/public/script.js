const form = document.getElementById("chatForm");
const input = document.getElementById("messageInput");
const chat = document.getElementById("chat");
const sendBtn = document.getElementById("sendBtn");
const clearBtn = document.getElementById("clearBtn");

function addMessage(sender, text, type) {
  const box = document.createElement("div");
  box.className = `message ${type}`;

  const title = document.createElement("strong");
  title.textContent = sender;

  const p = document.createElement("p");
  p.textContent = text;

  box.appendChild(title);
  box.appendChild(p);
  chat.appendChild(box);
  chat.scrollTop = chat.scrollHeight;
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();

  const message = input.value.trim();
  if (!message) return;

  addMessage("You", message, "user");
  input.value = "";
  sendBtn.disabled = true;
  sendBtn.textContent = "Thinking...";

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message })
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || "Request failed.");
    }

    addMessage("Gemini", data.reply, "bot");
  } catch (error) {
    addMessage("Error", error.message, "bot");
  } finally {
    sendBtn.disabled = false;
    sendBtn.textContent = "Send";
    input.focus();
  }
});

clearBtn.addEventListener("click", () => {
  chat.innerHTML = "";
  addMessage("Gemini", "Chat cleared. Ask me a new question.", "bot");
});

input.addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    form.requestSubmit();
  }
});