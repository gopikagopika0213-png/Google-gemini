import express from "express";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: "1mb" }));
app.use(express.static("public"));

const apiKey = process.env.GEMINI_API_KEY;
const ai = apiKey ? new GoogleGenAI({ apiKey }) : null;

app.post("/api/chat", async (req, res) => {
  try {
    const message = String(req.body?.message || "").trim();

    if (!message) {
      return res.status(400).json({ error: "Please enter a message." });
    }

    if (!ai) {
      return res.status(500).json({
        error: "Gemini API key is missing. Add GEMINI_API_KEY to your .env file."
      });
    }

    const response = await ai.models.generateContent({
      model: "gemini-flash-latest",
      contents: message
    });

    res.json({
      reply: response.text || "I could not generate a response."
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      error: "Something went wrong while contacting Gemini. Check your API key and try again."
    });
  }
});

app.listen(PORT, () => {
  console.log(`Google Gemini Project running at http://localhost:${PORT}`);
});